<?php
	$username="uaehlovv_elife";
	$password="$]kI6]p0c95%";
	$server="localhost";
	$db="uaehlovv_elifedb";
	$con=mysqli_connect($server,$username,$password,$db);
?>