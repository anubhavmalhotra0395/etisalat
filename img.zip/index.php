<!DOCTYPE html>
<html lang="en">
  <head>
      
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>UAE HOME INTERNET</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="flaticon.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Commissioner:wght@500&display=swap" rel="stylesheet">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
  <link rel="icon" href="https://ttf.thethoughtfactory.ae/SiteAssets/img/logo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-- Global site tag (gtag.js) - Google Ads: 363499546 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-363499546"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-363499546');
</script>


<!-- Event snippet for Submit lead form conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-363499546/qkSnCNymjr4CEJqgqq0B'});
</script>
  </head>
  <body>
    </script>
    
    
      
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60891aa85eb20e09cf375151/1f4bp097l';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

 <script type="text/javascript">
  function validate()
  {
    var text = document.getElementById("mobile").value;
    var regex = /^[0][5](0|2|3|4|5|8|6){1}[0-9]{7}$/;
    if(regex.test(text) && text.length==10) 
    {
      return true;
    }
    else
    {
      alert("Mobile Number Invalid");
      return false;
    }
  }
  </script>
  
 <!--Alert Message-->
  <!--
<div class="modal fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
  <div class="modal-dialog" id="ook">
  <div class="col-md-12 col-11">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#f9f9f9; ">
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="opacity: 1;"></button>
      </div>
      <div class="modal-body" >
      <img src="img/188.jpg" id="planok">
      <br>
      <br>
       <form  action="mailok.php" method="post"  id="contactForm" enctype="multipart/form-data">
                                <h6 style="text-align: center; ">This offer is applicable only for selected areas. For more details, submit your information here, our representative will contact you shortly!</h6><br>
                                <input type="text" name="name1" class="modal-input" placeholder="Enter your Name" required><br><br>
                                
                                <input type="text" class="modal-input" name="number2" placeholder="Enter your Mobile Number" required><br><br>
                                
                                <input type="text" name="email3" class="modal-input" placeholder="Enter your Address" required><br><br>
                              
                                <div class="modal-footer">
                                 <input type="submit" class="btn" style=" justtify-content:center;margin: 0px auto; background-color: #719E19; color:white;" name="submitok">
                                 </div>
          </form>
      </div>
      </div>
      
      </div>
    </div>
  </div>
<!--End Alert Message-->

  


  <div style="position: fixed; width: 100%; z-index: 99;">
                            <div class="links">
                                <ul class="social">
                        
                                    <li style="display:inline-block;"><a href="https://www.facebook.com/thethoughtfactorydmcc" target="_blank"><img src="img/fb.png" style="padding-right:10px; width:30px; height:20px;"></a></li>
                                    <li style="display:inline-block;"><a href="https://www.linkedin.com/company/the-thought-factory-dmcc/about/?viewAsMember=true" target="_blank"><img src="img/in.png" style="padding-right:10px; width:30px; height:20px;"></a></li>
                                    <li style="display:inline-block;"><a href="https://www.instagram.com/thethoughtfactorydmcc/" target="_blank"><img src="img/insta.png" style="padding-right:10px; width:30px; height:20px;"></a></li>
                                </ul>
                            </div>
    <!-- Navbar-->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow p-3 mb-5 bg-white rounded" id="idnav">
        <a href="#" class="navbar-brand ml-auto"><img src="img/logo.jpg" id="logo"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon" ></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="nav navbar-nav ms-auto">
          <li class="nav-item"><a href="#" class="nav-link">HOME</a></li>
          <li class="nav-item"><a data-bs-toggle="modal" data-bs-target="#exampleModal" class="nav-link" style="cursor:pointer;">CONTACT</a></li>      
          <li class="nav-item"><a href="pp.php" class="nav-link"><i class="fas fa-mobile-alt style="overflow-y:hidden;"></i>&nbsp&nbspPOSTPAID PLANS</a></li>                               
          <li class="nav-item"><a href="tel:+971569902289" class="nav-link"><i class="fas fa-phone-square-alt fa-lg" style="overflow-y:hidden;"></i>&nbsp&nbspCALL US ON:&nbsp &nbsp+971 547930545</a></li>         
        </ul>
        </div>
    </nav>
    <!-- End Navbar-->
  </div>
  

   
    <!--Carousel start-->
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/banner.jpg" class="img-fluid" id="co1" alt="...">
      <div class="carousel-caption d-none d-md-block">
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/newbanner.png" class="img-fluid"   id="co1" alt="...">
      <div class="carousel-caption d-none d-md-block">
      </div>
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev" id="cnp">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next" id="cnp">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<!--Carousel End-->

<!--Carousel start-->
    <div id="carouselExampleCaptions2" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions2" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions2" data-bs-slide-to="1" aria-label="Slide 2"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/yeye.jpg" class="img-fluid" id="co3" alt="...">
      <div class="carousel-caption d-none d-md-block">
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/yaya.jpg" class="img-fluid"   id="co3" alt="...">
      <div class="carousel-caption d-none d-md-block">
      </div>
    </div>
  </div>
 <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions2" data-bs-slide="prev" id="cnp2">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions2" data-bs-slide="next" id="cnp2">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<!--Carousel End-->

<div class="container" id="infoheads">
    <h6 style="overflow-y:hidden;" >Premium TV channels & faster internet speed for 3 months at no extra cost</h6>
    <p style="color:grey; font-size:12px;">Enjoy saving of up to AED 780 + Extra bonus speed boost (limited time offer)</p>
</div>
    <!-- Mobile Offers-->
    <div class="banner3" style=" background-image:url(img/bgc.png)">
      <p style="padding-left:20px; padding-top:35px;">Online exclusive</p>
<p style=" font-size:12px;  padding-right:60px; padding-left:20px;">Free installation worth AED 199 available on online orders for eLife Unlimited & eLife Lite packages</p>
    </div>
    </div>
    
     <!--Form-->
   <div class="row" style="overflow-y:hidden;" id="why">  
    <div class="col-lg-5 col-md-12 col-12"  id="contact">
    <div class="about-main-image">
      <form action="mail.php" method="post" onsubmit="return validate()" enctype"multipart/form-data" >
        <div class="col-lg-12 col-md-12" id="fill-form">
          <h2 id="class-header1">Fill in this form and we will call you back in 15 minutes</h2><br>
        <div class="form-group">
          <input type="text" class="form-control" name="name" placeholder="Enter your Name">
        </div><br>
        <div class="form-group">
          <input type="text" class="form-control" name="email" placeholder="Enter your Email">
        </div><br>
        <div class="form-group">
            <input type="text" class="form-control" name="mnumber" placeholder="Enter your Mobile Number" id="mobile" required>
        </div><br>
        <div class="form-group">
          <input type="text" class="form-control" name="address" placeholder="Enter your Address">
        </div><br>
          <button type="submit" class="btn btn-dark" name="submit1">SUBMIT</button>
        </div>
    </form>
  </div>
  </div>
  </div>
  <!--End Form-->
   <!--Offers-->
  <div class="ban">
      <img src="img/okkk.png" class="img-fluid" alt="online" >
    </div>
    <!--End Offers-->
    
    
  
    <!--End Offers-->
    
  
<!--Packages-->
 
    <div class="row justify-content-center" id="elifeh">
      <h2 id="elifehead">eLife Unlimited Plans</h2>
        <div class="col-md-3 col-10 bg-white shadow" style="overflow-y:hidden; padding: 0px 0px 0px 0px;" id="packages3">
          <div  style="background:url(img/plan-cards-illustration.svg) right center no-repeat,linear-gradient(
45deg
,#ff8000,#353738); border-radius: .5rem .5rem 0 0; width: 100%;">
          <div class="container">
              <p style="background-color: #ff8000; padding: 4px 4px; border-radius: 0 0 .25rem .25rem; width: 220px; color: white; font-size: 14px;">LIMITED TIME OFFER 40% OFF</p>
              <br>
              <br>
              <h4 style="font-size: 14px; color:white;">ELIFE</h4>
              <h4 style="color:white; padding-bottom: 10px;" id="elh">Unlimited Sports</h4>
          </div>
          </div>
          <div class="container">
            <p  style="padding-top:10px; font-size:16px; padding-bottom: 0px; color: grey;">INTERNET</p>
            <p style="font-size:16px; padding-bottom: 10px; font-size:16px;  margin-top:-20px;">750 MBPS</p>
            <img src="img/750.png" style="margin-top:-60px; width: 100%;">
            <p style="margin-top:-30px; font-size: 12px; color:grey;">Free limited time speed boost until 31 Oct’21</p>
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p  style="padding-top:10px;  padding-bottom: 0px; color: grey;" id="elc">TV</p>
            <p style="margin-top:-20px;" id="elc"><b>200+</b></p>  
            <p  style="padding-top:10px;  margin-top: -30px; color: grey;" id="elc">HD TV Channels</p>
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p style="font-size: 13px; color:grey; padding-top: 10px;">Upgraded speed 750Mbps instead of original speed 500Mbps</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">4K TV Box, Wi-Fi Router & Phone</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">OnDemand Movies & Regional TV AddOn</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">Free Calls to UAE Landlines</p>    
          </div>

          <div class="container" style="padding-bottom: 10px;">
            <div class="horizontal_dotted_line" style="margin-top:0px; "></div>
          </div>

          <div class="container">
              <p style="background-color: #FFECD9; color: #FF9036; width: 60%; padding: 3px 2px 5px 7px; border-radius: 10px; font-size:14px;">24-month commitment</p>
          </div>

          <div class="container" style="margin-top:-10px; overflow-y: hidden;" id="elm2">
            <span style="font-size: 26px; color:#ff8000;">389.00</span>
           <span style="font-size: .875rem; color:#FF9036;">AED/Month</span><br>
            <span style="color:#fff;background-color: #ff8000;    border-radius: 10px;
    padding: 2px 7px 3px;margin-right: .25rem; font-size:13px;">was <del style="font-size:13px;">649.00 AED</del> 
    </span>
    <span style=" font-size: 12px; color:grey;">5% VAT excluded</span>
          </div>

          <button class="btn w-100" id="packages-buttonoffer" data-bs-toggle="modal" data-bs-target="#exampleModal">BUY NOW</button>

        </div>



        <div class="col-md-3 col-10 bg-white shadow" style="overflow-y:hidden; padding: 0px 0px 0px 0px;" id="packages3">
          <div  style="background:url(img/plan-cards-illustration.svg) right center no-repeat,linear-gradient(
45deg
,#ff8000,#353738); border-radius: .5rem .5rem 0 0; width: 100%;">
          <div class="container">
              <p style="background-color: #ff8000; padding: 4px 4px; border-radius: 0 0 .25rem .25rem; width: 220px; color: white; font-size: 14px;">LIMITED TIME OFFER 35% OFF</p>
              <br>
              <br>
              <h4 style="font-size: 14px; color:white;">ELIFE</h4>
              <h4 style="color:white; padding-bottom: 10px;" id="elh">Unlimited Entertainment</h4>
          </div>
          </div>
          <div class="container">
            <p  style="padding-top:10px; font-size:16px; padding-bottom: 0px; color: grey;">INTERNET</p>
            <p style="font-size:16px; padding-bottom: 10px; font-size:16px;  margin-top:-20px;">750 MBPS</p>
            <img src="img/750.png" style="margin-top:-60px; width: 100%;">
            <p style="margin-top:-30px; font-size: 12px; color:grey;">Free limited time speed boost until 31 Oct’21</p>
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p  style="padding-top:10px;  padding-bottom: 0px; color: grey;" id="elc">TV</p>
            <p style="margin-top:-20px;" id="elc"><b>45+</b></p>  
            <p  style="padding-top:10px;  margin-top: -40px; color: grey;display: inline-block;" id="elc">Premium OSN Channels</p>
            <img src="img/osn1.svg" alt="" style="display: inline-block; margin-top: -50px; padding-left:5px;">
            <img class="alignnone size-full wp-image-161" src="img/starzplay1.svg" alt="" style="display:inline-block; margin-top: -50px;">
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p style="font-size: 13px; color:grey; padding-top: 10px;">Upgraded speed 750Mbps instead of original speed 500Mbps</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">4K TV Box, Wi-Fi Router & Phone</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">OnDemand Movies & Regional TV AddOn</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">Free Calls to UAE Landlines</p>    
          </div>

          <div class="container" style="padding-bottom: 10px;">
            <div class="horizontal_dotted_line" style="margin-top:0px; "></div>
          </div>

          <div class="container">
              <p style="background-color: #FFECD9; color: #FF9036; width: 60%; padding: 3px 2px 5px 7px; border-radius: 10px; font-size:14px;">24-month commitment</p>
          </div>

          <div class="container" style="margin-top:-10px; overflow-y: hidden; margin-bottom:20px;">
            <span style="font-size: 26px; color:#FF9036;">389.00</span>
            <span style="font-size: .875rem; color:#FF9036;">AED/Month</span><br>
            <span style="color:#fff;background-color: #ff8000;    border-radius: 10px;
    padding: 2px 7px 3px;margin-right: .25rem; font-size:13px;">was <del style="font-size:13px;">599.00 AED</del> 
    </span>
    <span style=" font-size: 12px; color:grey;">5% VAT excluded</span>
          </div>

          <button class="btn w-100" id="packages-buttonoffer" data-bs-toggle="modal" data-bs-target="#exampleModal">BUY NOW</button>

        </div>

        <div class="col-md-3 col-10 bg-white shadow" style="overflow-y:hidden; padding: 0px 0px 0px 0px;" id="packages5">
          <div  style="background:url(img/plan-cards-illustration.svg) right center no-repeat,linear-gradient( 
45deg
 ,#719e19,#353738); border-radius: .5rem .5rem 0 0; width: 100%;">
          <div class="container">
              <br>
              <br>
              <br>
              <br>
              <h4 style="font-size: 14px; color:white;">ELIFE</h4>
              <h4 style="color:white; padding-bottom: 7px;" id="elh">Unlimited Starter</h4>
          </div>
          </div>
          <div class="container">
            <p  style="padding-top:10px; font-size:16px; padding-bottom: 0px; color: grey;">INTERNET</p>
            <p style="font-size:16px; padding-bottom: 10px; font-size:16px;  margin-top:-20px;">500 MBPS</p>
            <img src="img/500.png" style="margin-top:-60px; width: 100%;">
            <p style="margin-top:-30px; font-size: 12px; color:grey;">Free limited time speed boost until 31 Oct’21</p>
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p  style="padding-top:10px; padding-bottom: 0px; color: grey;" id="elc">TV</p>
            <p style="margin-top:-20px; " id="elc"><b>45+</b></p>  
            <p  style="padding-top:10px; margin-top: -30px; color: grey;" id="elc">HD TV Channels</p>
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p style="font-size: 13px; color:grey; padding-top: 10px;">Upgraded speed 500Mbps instead of original speed 250Mbps</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">4K TV Box, Wi-Fi Router & Phone</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">OnDemand Movies & Regional TV AddOn</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">Free Calls to UAE Landlines</p>    
          </div>

          <div class="container" style="padding-bottom: 10px;">
            <div class="horizontal_dotted_line" style="margin-top:0px; "></div>
          </div>

          <div class="container">
              <p style="background-color: #EAF1DD; color: #719e19; width: 60%; padding: 3px 2px 5px 7px; border-radius: 10px; font-size:14px;">24-month commitment</p>
          </div>

          <div class="container" style="margin-top:-10px; overflow-y: hidden;" id="elm">
            <span style="font-size: 26px; color:#719e19;">389.00</span>
            <span style="font-size: .875rem; color:#719e19;">AED/Month</span><br>
    <span style=" font-size: 12px; color:grey;">5% VAT excluded</span>
          </div>

          <button class="btn w-100" id="packages-button" data-bs-toggle="modal" data-bs-target="#exampleModal">BUY NOW</button>

        </div>
    </div>



    <div class="row justify-content-center" id="okrow">
       <div class="col-md-3 col-10 bg-white shadow" style="overflow-y:hidden; padding: 0px 0px 0px 0px;" id="packages5">
          <div  style="background:url(img/plan-cards-illustration.svg) right center no-repeat,linear-gradient( 
45deg
 ,#719e19,#353738); border-radius: .5rem .5rem 0 0; width: 100%;">
          <div class="container">
              <br>
              <br>
              <br>
              <br>
              <h4 style="font-size: 14px; color:white;">ELIFE</h4>
              <h4 style="color:white; padding-bottom: 7px;" id="elh">Unlimited Premium 500</h4>
          </div>
          </div>
          <div class="container">
            <p  style="padding-top:10px; font-size:16px; padding-bottom: 0px; color: grey;">INTERNET</p>
            <p style="font-size:16px; padding-bottom: 10px; font-size:16px;  margin-top:-20px;">500 MBPS</p>
            <img src="img/500.png" style="margin-top:-60px; width: 100%;">
            <p style="margin-top:-30px; font-size: 12px; color:grey;">Premium Speed - Premium Content</p>
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p  style="padding-top:10px;  padding-bottom: 0px; color: grey;" id="elc">TV</p>
            <p style="margin-top:-20px; " id="elc"><b>100+</b></p>  
            <p  style="padding-top:10px; margin-top: -30px; color: grey; display: inline-block;" id="elc">Premium Sports <br>&<br>
            Entertainment</p>
            <img src="img/osn1.svg" alt="" style="display: inline-block; margin-top: -30px; padding-left:5px;">
            <img class="alignnone size-full wp-image-161" src="img/starzplay1.svg" alt="" style="display:inline-block; margin-top: -30px;">
            <img class="alignnone size-full wp-image-161" src="img/bein1.svg" alt="" style="display:inline-block; margin-top: -30px;">
            <img class="alignnone size-full wp-image-161" src="img/criclife1.svg" alt="" style="display:inline-block; margin-top: -30px;">
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p style="margin-top: 10px; font-size: 13px; color:grey;">4K TV Box, Wi-Fi Router & Phone</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">OnDemand Movies & Regional TV AddOn</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">Free Calls to UAE Landlines</p>    
          </div>

          <div class="container" style="padding-bottom: 10px;">
            <div class="horizontal_dotted_line" style="margin-top:0px; "></div>
          </div>

          <div class="container">
              <p style="background-color: #EAF1DD; color: #719e19; width: 60%; padding: 3px 2px 5px 7px; border-radius: 10px; font-size:14px;">24-month commitment</p>
          </div>

          <div class="container" style="margin-top:-10px; overflow-y: hidden; margin-bottom:20px;">
            <span style="font-size: 26px; color:#719e19;">1229.00</span>
            <span style="font-size: .875rem; color:#719e19;">AED/Month</span><br>
    <span style=" font-size: 12px; color:grey;">5% VAT excluded</span>
          </div>

          <button class="btn w-100" id="packages-button" data-bs-toggle="modal" data-bs-target="#exampleModal">BUY NOW</button>

        </div>

          <div class="col-md-3 col-10 bg-white shadow" style="overflow-y:hidden; padding: 0px 0px 0px 0px;" id="packages5">
          <div  style="background:url(img/plan-cards-illustration.svg) right center no-repeat,linear-gradient( 
45deg
 ,#719e19,#353738); border-radius: .5rem .5rem 0 0; width: 100%;">
          <div class="container">
              <br>
              <br>
              <br>
              <br>
              <h4 style="font-size: 14px; color:white;">ELIFE</h4>
              <h4 style="color:white; padding-bottom: 7px;" id="elh">Unlimited Premium 1G</h4>
          </div>
          </div>
          <div class="container">
            <p  style="padding-top:10px; font-size:16px; padding-bottom: 0px; color: grey;">INTERNET</p>
            <p style="font-size:16px; padding-bottom: 10px; font-size:16px;  margin-top:-20px;">1 GBPS</p>
            <img src="img/1gb.png" style="margin-top:-60px; width: 100%;">
            <p style="margin-top:-30px; font-size: 12px; color:grey;">Up-to 25 Streaming Devices</p>
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p  style="padding-top:10px;  padding-bottom: 0px; color: grey;" id="elc">TV</p>
            <p style="margin-top:-20px; " id="elc"><b>45+</b></p>  
            <p  style="padding-top:10px;  margin-top: -30px; color: grey; display: inline-block;" id="elc">Premium Sports <br>&<br>
            Entertainment</p>
            <img src="img/osn1.svg" alt="" style="display: inline-block; margin-top: -30px; padding-left:5px;">
            <img class="alignnone size-full wp-image-161" src="img/starzplay1.svg" alt="" style="display:inline-block; margin-top: -30px;">
            <img class="alignnone size-full wp-image-161" src="img/bein1.svg" alt="" style="display:inline-block; margin-top: -30px;">
            <img class="alignnone size-full wp-image-161" src="img/criclife1.svg" alt="" style="display:inline-block; margin-top: -30px;">
          </div>

          <div class="container">
            <div class="horizontal_dotted_line" style="margin-top:0px;"></div>
          </div>

          <div class="container">
            <p style="margin-top: 10px; font-size: 13px; color:grey;">4K TV Box, Wi-Fi Router & Phone</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">OnDemand Movies & Regional TV AddOn</p>
            <p style="margin-top:-5px; font-size: 13px; color:grey;">Free Calls to UAE Landlines</p>    
          </div>

          <div class="container" style="padding-bottom: 10px;">
            <div class="horizontal_dotted_line" style="margin-top:0px; "></div>
          </div>

          <div class="container">
              <p style="background-color: #EAF1DD; color: #719e19; width: 60%; padding: 3px 2px 5px 7px; border-radius: 10px; font-size:14px;">24-month commitment</p>
          </div>

          <div class="container" style="margin-top:-10px; overflow-y: hidden; margin-bottom:20px;">
            <span style="font-size: 26px; color:#719e19;">2940.00</span>
            <span style="font-size: .875rem; color:#719e19;">AED/Month</span><br>
    <span style=" font-size: 12px; color:grey;">5% VAT excluded</span>
          </div>

          <button class="btn w-100" id="packages-button" data-bs-toggle="modal" data-bs-target="#exampleModal">BUY NOW</button>

        </div>


    </div>
    </div>
    </div>

    <!--End Packages-->
    <!--Form-->
   <div class="row" style="overflow-y:hidden;" id="why2">  
    <div class="col-lg-5 col-md-12 col-12"  id="contact">
    <div class="about-main-image">
      <form action="mail.php" method="post" onsubmit="return validate()" enctype"multipart/form-data" >
        <div class="col-lg-12 col-md-12" id="fill-form2">
          <h2 id="class-header1">Fill in this form and we will call you back in 15 minutes</h2><br>
        <div class="form-group">
          <input type="text" class="form-control" name="name" placeholder="Enter your Name">
        </div><br>
        <div class="form-group">
          <input type="text" class="form-control" name="email" placeholder="Enter your Email">
        </div><br>
        <div class="form-group">
            <input type="text" class="form-control" name="mnumber" placeholder="Enter your Mobile Number" id="mobile" required>
        </div><br>
        <div class="form-group">
          <input type="text" class="form-control" name="address" placeholder="Enter your Address">
        </div><br>
          <button type="submit" class="btn btn-dark" name="submit1">SUBMIT</button>
        </div>
    </form>
  </div>
  </div>
  </div>
  <!--End Form-->

    
    <!--Other ELife Packages-->
    <div class="container">
    <div class="col-md-4" style="margin: 0px auto;">
      <a href="elite.php"><button class="btn w-100" id="packages-buttonelite">CLICK HERE FOR ELITE PACKAGES</button></a>
    </div>
    </div>
    <!--End Other Elife Packages-->
    
    
    
    <!--Add Ons-->
    
    <div class="row justify-content-center" style=" background-image: url('img/bgp.jpg');margin-top:0px;padding-top:30px; padding-left:20px; padding-right:20px; padding-bottom:40px; margin-bottom: 50px;">
        
        <div class="card shadow" id="card1">
          <div class="card-body">
            <h5 class="card-title" style="overflow-y:hidden;">Regional & Premium TV packages</h5>
              <p class="card-text" style="margin-bottom: 40px; font-size:14px;">Experience the best of television entertainment with our wide variety of packages.</p>
              <a href="rp.php"><button class="btn w-100" id="packages-button">LEARN MORE</button></a>
          </div>
      </div>

      <div class="card shadow" id="card1">
          <div class="card-body">
            <h5 class="card-title" style="overflow-y:hidden;">Home protection</h5>
              <p class="card-text" style="font-size:14px;">Protect your belongings with Etisalat & its partner (Union Insurance Company) & get accommodation if your home is uninhabitable for up to 15 days.</p>
              <a href="hp.php"><button class="btn w-100" id="packages-button">LEARN MORE</button></a>
          </div>
      </div>

      <div class="card shadow" id="card1">
          <div class="card-body">
            <h5 class="card-title" style="overflow-y:hidden;">eLife ICP</h5>
              <p class="card-text" style="margin-bottom: 85px; font-size:14px;">Talk locally or internationally while at home, till the sun rises.</p>
              <a href="icp.php"><button class="btn w-100" id="packages-button">LEARN MORE</button></a>
          </div>
      </div>
    </div>
    <!--End Add Ons-->
    
    <!-- Start Boxes Area -->
    <h4 style="overflow-y: hidden;margin-top:0px; margin-bottom:40px; text-align:center;">All eLife Packages Include</h4>
        <section class="boxes-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-box">
                            <div class="icon" style="overflow-y:hidden;">
                                <i class="flaticon-tele-phone" ></i>
                            </div>

                            <h3>Cordless Phone</h3>

                            <p>Free landline to landline calls.<br> Enjoy great savings</p>

                            <div class="image-box">
                                <img src="img/1.png" alt="image">
                                <img src="img/1.png" alt="image">
                            </div>
                        </div>
                    </div>

                    

                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-box">
                            <div class="icon"  style="overflow-y:hidden; padding-top:10px;">
                                <i class="fas fa-mobile-alt"></i>
                            </div>

                            <h3>eLifeON App</h3>

                            <p>Free <br>elifeON app</p>


                            <div class="image-box">
                                <img src="img/1.png" alt="image">
                                <img src="img/1.png" alt="image">
                            </div>
                        </div>
                    </div>
          
          <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-box">
                            <div class="icon"  style="overflow-y:hidden; padding-top:10px;">
                                <i class="material-icons" style="font-size:36px">router</i>
                            </div>

                            <h3>Wifi Router</h3>

                            <p>Free advanced Router<br>with Advanced Coverage</p>

                            <div class="image-box">
                                <img src="img/1.png" alt="image">
                                <img src="img/1.png" alt="image">
                            </div>
                        </div>
                    </div>
          
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-box">
                            <div class="icon"  style="overflow-y:hidden;  padding-top:10px;">
                               <i class="material-icons" style="font-size:36px">tv</i>
                            </div>

                            <h3>4k TV <br> setup box</h3>

                            <p>Free 4k tv setup box<br></p>


                            <div class="image-box">
                                <img src="img/1.png" alt="image">
                                <img src="img/1.png" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Boxes Area -->
        </div>
        </div>

    
    

    

    
    <!-- Contact text-->
    <p id="last-text">Existing subscribers can call 800-101 or visit www.etisalat.ae for the latest applicable offers</p>
    <!--End Contact text-->

    <!--Footer-->
    <div class="footer bg-dark">
      <p id="footer-text1">This landing page is powered by TTF</p>
    </div>
    
    
     <button id="btn_model" style="display: none;" type="button" class="btn btn-info btn-lg" data-bs-toggle="modal" data-bs-target="#exampleModal">Open Modal</button>
    
    <!-- Modal -->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
  <div class="modal-dialog" id="ook">
    <div class="row" id="ok2">
  <div class="col-md-12 col-11">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#f9f9f9; ">
        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="opacity: 1;"></button>
      </div>
      <div class="modal-body">
        <form  action="mailok.php" method="post"  id="contactForm" enctype="multipart/form-data">
                                <h6 style="text-align: center; ">Fill this form and we will get back to you!</h6><br>
                                <input type="text" name="name1" class="modal-input" placeholder="Enter your Name" required><br><br>
                                
                                <input type="text" class="modal-input" name="number2" placeholder="Enter your Mobile Number" required><br><br>
                                
                                <input type="text" name="email3" class="modal-input" placeholder="Enter your Address" required><br><br>
                                
                                <select name="packages" id="pckgs" style="max-width: 300px; height: 30px; line-height: 30px; margin-top: 5px; background-color: #f9f9f9; border:1px solid grey;">
                                    <option value="New WIFI Plan">New WIFI Plan</option>
                                    <option value="New Postpaid plan">New POST PAID Plan</option>
                                    <option value="Regional & Premium TV Packages">Regional & Premium TV packages</option>
                                    <option value="home protection plan">Home Protection Plan</option>
                                    <option value="eLife ICP Plan">eLife ICP Plan</option>
                                    <option value="Customer Service">Customer Service</option>
                                    <option value="Technical Issues">Technical Issues</option>
                                </select><br><br>
                                <div class="modal-footer">
                                 <input type="submit" class="btn" style=" justtify-content:center;margin: 0px auto; background-color: #719E19; color:white;" name="submitok">
                                 </div>
          </form>
      </div>
    </div>
  </div>
</div>
</div>
</div>


 

     <script type="text/javascript">
    $(function () {
        setTimeout(function () {
            $('#exampleModal').modal('show');
        }, 100000);
    });
</script>     

 <script type="text/javascript">
    $(function () {
        setTimeout(function () {
            $('#exampleModal3').modal('show');
        }, 10000);
    });
</script>     
         
         


    <script>
    var url = 'https://wati-integration-service.clare.ai/ShopifyWidget/shopifyWidget.js?92020';
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = url;
    var options = {
  "enabled":true,
  "chatButtonSetting":{
      "backgroundColor":"#4dc247",
      "ctaText":"",
      "borderRadius":"25",
      "marginLeft":"20",
      "marginBottom":"20",
      "marginRight":"50",
      "position":"left"
  },
  "brandSetting":{
      "brandName":"",
      "brandSubTitle":"",
      "brandImg":"https://cdn.clare.ai/wati/images/WATI_logo_square_2.png",
      "welcomeText":"Chat with us to get exciting offers!",
      "messageText":"",
      "backgroundColor":"#0a5f54",
      "ctaText":"Start Chat",
      "borderRadius":"25",
      "autoShow":false,
      "phoneNumber":"971547930545"
  }
};
    s.onload = function() {
        CreateWhatsappChatWidget(options);
    };
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);
</script>


  
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

 
  </body>
</html>

<!--
<script type="text/javascript">
  
  if (window.history && history.pushState) {
    addEventListener('load', function() {
        history.pushState(null, null, null); // creates new history entry with same URL
        addEventListener('popstate', function() {
         
          $('#btn_model').click();
             var stayOnPage = confirm("Please stay with us , We have some exciting offers for you!");
             if (!stayOnPage) {
              var confirmok = confirm("Are You sure?");
                if (!confirmok) {
               
                history.pushState(null, null, null);
             $('#btn_model').click();
                }
                else {
                 window.location.href = 'http://www.google.com';
               history.pushState(null, null, null); 
           
             }
 
             } else {
              history.pushState(null, null, null);
             $('#btn_model').click();
             }
        });    
    });
    
}


//$("#btn_submit").click(function(e){
  $("#btn_submit").on("click", function(e) {
  e.preventDefault();
      //  window.history.back();
        window.location.href="index2.php";
    }); 



$( document ).ready(function() {
  
//  $('#btn_model').click();
});

// window.alert = function() {
//     debugger;
// }
         
  /* window.addEventListener("beforeunload", function (e) {
    if(!e) e = window.event;
    //e.cancelBubble is supported by IE - this will kill the bubbling process.
    e.cancelBubble = true;
   //  e.cancelBubble.attr('disabled', false);
   window.location.href='back1.html';
    e.returnValue = 'You sure you want to leave?'; //This is displayed on the dialog

   
   
    //e.stopPropagation works in Firefox.
    if (e.stopPropagation) {
        e.stopPropagation();
        e.preventDefault();}                          //Webkit, Safari, Chrome
    });

   

  //  window.onbeforeunload= "goodbye";   */

            
</script>
-->
